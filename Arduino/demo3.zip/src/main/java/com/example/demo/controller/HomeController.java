package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.vo.ChannelVO;

@Controller
public class HomeController {
	
	List<ChannelVO> list=new ArrayList<>();
	@GetMapping("/home")
	public String home() {
		return "home";
	}
	@PostMapping("/sensor")
	public void sensor(@RequestBody ChannelVO vo ) {
		System.out.println(vo);
		for(int i =0;i<20;i++) {
			list.add(vo);
		}

	}
	@GetMapping("/sensor")
	public String Sensor1(Model model) {
		Float humid= 0.0f;
		Float temp= 0.0f;
		System.out.println("여기는 get");
		model.addAttribute("item",list);
		for( ChannelVO i  : list) {
			humid +=Float.parseFloat(i.getHumi());
			temp +=Float.parseFloat(i.getTemp());
		}
		model.addAttribute("h",humid/list.size());
		model.addAttribute("t",temp/list.size());
		//list.removeAll(null);
		return "sensor";
	}
}
