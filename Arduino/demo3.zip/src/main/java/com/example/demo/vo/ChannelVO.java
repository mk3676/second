package com.example.demo.vo;

public class ChannelVO {
	  private String api_key;
	  private String sensor;
	  private String temp;
	  private String humi;
	public String getApi_key() {
		return api_key;
	}
	public void setApi_key(String api_key) {
		this.api_key = api_key;
	}
	public String getSensor() {
		return sensor;
	}
	public void setSensor(String sensor) {
		this.sensor = sensor;
	}
	public String getTemp() {
		return temp;
	}
	public void setTemp(String temp) {
		this.temp = temp;
	}
	public String getHumi() {
		return humi;
	}
	public void setHumi(String humi) {
		this.humi = humi;
	}
	@Override
	public String toString() {
		return "ChannelVO [api_key=" + api_key + ", sensor=" + sensor + ", temp=" + temp + ", humi=" + humi + "]";
	}
	
	
	
}
