package com.example.myapplication;


import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;

import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private TextView tempDataTextView;
    private TextView humidDataTextView;
    private Button button;
    private Handler handler;
    private Runnable dataUpdateRunnable;
    private  int cnt=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tempDataTextView = findViewById(R.id.temp_data_text_view);
        humidDataTextView = findViewById(R.id.humid_data_text_view);
        button= findViewById(R.id.button);

        handler = new Handler();
        dataUpdateRunnable = new Runnable() {
            @Override
            public void run() {
                updateData();
                handler.postDelayed(this, 2000); // Schedule the next update after 1 second
            }
        };

        // Start the data update loop
        handler.postDelayed(dataUpdateRunnable, 2000);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Stop the data update loop when the activity is destroyed
        handler.removeCallbacks(dataUpdateRunnable);
    }

    private void updateData() {
        new NetworkTask().execute();
    }

    private class NetworkTask extends AsyncTask<Void, Void, String[]> {

        @Override
        protected String[] doInBackground(Void... params) {
            String[] result = new String[2];
            String[] finalResult = new String[2];
            String sensorData = "";

            try {
                URL url = new URL("http://192.168.0.63:8080/sensor");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String line;
                StringBuilder response = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                reader.close();
                conn.disconnect();

                sensorData = response.toString();
                // 정규 표현식 패턴
                String pattern = "<tfoot>(.*?)</tfoot>";
                Pattern regex = Pattern.compile(pattern);
                Matcher matcher = regex.matcher(sensorData);

                if (matcher.find()) {
                    String numbers = matcher.group(1);
                    String[] numberArray = numbers.split("</td>\\s*<td>");
                    if (numberArray.length == 2) {
                        result[0] = numberArray[0].replaceAll("<td>", "").replaceAll("</td>", "");
                        result[1] = numberArray[1].replaceAll("<td>", "").replaceAll("</td>", "");

                    }
                    for ( int i =0 ;i<finalResult.length;i++) {
                        regex = Pattern.compile("\\d+(\\.\\d+)?"); // 정규식 패턴
                        matcher = regex.matcher(result[i]);
                        while (matcher.find()) {
                            String number = matcher.group();
                            finalResult[i]=number;
                           // Log.d("result", number);
                        }
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return finalResult;
        }

        @Override
        protected void onPostExecute(String[] result) {
            if (result.length == 2) {
                tempDataTextView.setText(result[0]);
                humidDataTextView.setText(result[1]);
            }
            //button.getText()+""+ cnt++ + "초"
            button.setText(cnt++ + "초");
        }
    }
}
